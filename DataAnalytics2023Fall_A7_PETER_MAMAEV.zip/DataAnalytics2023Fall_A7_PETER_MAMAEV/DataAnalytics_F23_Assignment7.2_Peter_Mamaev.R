library(tidyverse)
df <- read.csv("bank.csv", sep = ";", header = TRUE, stringsAsFactors = FALSE)
head(df)
df_full <- read.csv("bank-full.csv", sep = ";", header = TRUE, stringsAsFactors = FALSE)
head(df_full)
df_full


not_yes_or_no <- df_full$y[!(df_full$y %in% c("yes", "no"))]
# No invalid non-yes or no values.
# In Python this would be taken care of by a map function. I cannot find a map function in R so this is the next best thing.
df_full$y_bin <- ifelse(df_full$y == "yes", 1, ifelse(df_full$y == "no", 0, NA))
head(df_full)

count_ones <- sum(df_full$y_bin == 1, na.rm = TRUE)
count_zeros <- sum(df_full$y_bin == 0, na.rm = TRUE)
print(count_ones)
print(count_zeros)
# Target variable contains 5289 ones (customer said "yes"), 39922 zeros (customer said "no").
nrow(df_full)
# 5289 yes's + 3922 no's = 45211 rows total, checks out.

hist(df_full$balance)
hist(df$balance)
# This isn’t a super convenient distribution, but it does tell us that the distribution of balance is somewhat similar in both the df_full and the smaller df dataset. From this I extrapolate that the datasets do indeed have roughly similar distributions (as I’d expect them to from a random sampling).

qqplot(df_full$y_bin, df_full$balance)
# A very esoteric use of a qqplot, but it does show that on average the responders who said “yes” have higher bank account balances – which is strange, I would expect people with more money in their bank to be more hesitant about moving it over, especially from just a telemarketing call.
# This may just be extreme outliers skewing my perception a bit.

set.seed(123)
age_dataframe <- data.frame(age = sample(18:60, 100, replace = TRUE),
                   y_bin = sample(c("yes", "no"), 100, replace = TRUE))
age_group_bins <- cut(df_full$age, breaks = c(18, 25, 35, 45, 60), include.lowest = TRUE)
# Age groups chosen by myself.
# 18 is the minimum legal age to own a bank account.
# 60 is considered the retirement age in many developed countries.
# The rest are relatively even sprints between the two ages.
table_bins <- table(age_group_bins, df_full$y_bin)
prop_table <- prop.table(table_bins, margin = 1)
prop_matrix <- as.matrix(prop_table)
hist(df_full$age, beside = TRUE, main = "Proportion of 'yes' and 'no' across Age Groups", xlab = "Age Groups", ylab = "Proportion", legend.text = TRUE)

# Extreme outliers when it comes to measuring the amount of positive responses with DURATION.
# May need to remove those outside of the interquartile range for a more robust visualization.
set.seed(123)
Q1 <- quantile(df_full$duration, 0.25)
Q3 <- quantile(df_full$duration, 0.75)
IQR_dfduration <- Q3 - Q1
lower_bound <- Q1 - 1.5 * IQR_dfduration
upper_bound <- Q3 + 1.5 * IQR_dfduration
filtered_data <- subset(df_full, duration >= lower_bound & duration <= upper_bound)
hist(filtered_data$duration, main = "Histogram of Duration (Without Outliers)", xlab = "Duration", ylab = "Frequency")

# contact column seems to have a lot of unknowns
print(table(df_full$contact)["unknown"])
contact_values <- (table(df_full$contact))
contact_values
# cellular  telephone   unknown 
# 29285       2906      13020 
head(df_full)

help("ifelse")
# ifelse returns a value with the same shape as test which is filled with elements selected 
# from either yes or no depending on whether the element of test is TRUE or FALSE.

df_full$returningcust <- ifelse(df_full$pdays == -1, 0, 1)
count_retcust <- sum(df_full$returningcust == 1, na.rm = TRUE)
count_nonretcust <- sum(df_full$returningcust == 0, na.rm = TRUE)
print(count_retcust)
# 8257
print(count_nonretcust)
# 36954

job_sub_correlation <- table(df_full$job, df_full$y_bin)
job_sub_df <- as.data.frame.matrix(job_sub_correlation)
# The proportional likelihood of 1 in each job.
job_sub_df$prop_1 <- job_sub_df$`1` / rowSums(job_sub_df[, c("0", "1")])
# Finding the top 10 jobs with the highest proportion of '1's in the "y_bin" category, 
# i.e., where the customer called agreed to subscribe.
print(head(df[order(-job_sub_df$prop_1), , drop = FALSE], 10))
# Most likely jobs to subscribe are:
# 1. Student, 0.2867 possibility
# 2. Retired, 0.2279
# 3. Unemployed, 0.155
# 4. Administrative, 0.122
# 5. Self-employed, 0.1184
# But randomly checking independent variables isn't efficient.
# As such I plan to use the logistic regression to determine which variables have the lowest mean square error
# next to the predictor variable - these may be the most useful in figuring out what affetcs a customer's decision
# to subscribe to the bank.
# To reiterate - my independent variable is y_bin, which is just the binarized version of the y.

#head(df_full)


# Logistic Regression
# The goal of this model is to basically re-check the correlations between the most prevalent variables and the target variable.
logreg_model <- glm(y_bin ~ ., data = df_full, family = "binomial", maxit = 1000)
summary(logreg_model)
coefficients <- coef(logreg_model)
standard_errors <- summary(logreg_model)$coefficients[, "Std. Error"]
coefficients
standard_errors

coef_data <- data.frame(variable = names(coefficients), coefficient = coefficients, std_error = standard_errors)
sorted_coef_data <- coef_data[order(coef_data$std_error), ]
print(sorted_coef_data)
# Top 5 most correlated independent variables are:
# variable                                coefficient    std_error
# balance                       balance -4.217064e-16 1.063739e+02
# duration                     duration -1.064503e-13 1.355027e+03
# pdays                           pdays -3.952454e-14 6.833140e+03
# age                               age -4.491271e-14 3.901038e+04
# day                               day  2.378961e-13 4.401591e+04

# No null values in the balance independent variable.
sum(is.na(df_full$balance))
# No infinite values in the balance independent variable.
sum(!is.finite(df_full$balance))

# For the regression, I’m measuring the correlation between the target variable (“y_bin”) and the three most-correlated variables with it, which are the balance (the balance of the caller’s bank account), duration (call duration), and pdays (days since last call).
model_glm_balance <- glm(y_bin ~ balance, data = df_full, family = "binomial")
summary(model_glm_balance)

model_glm_duration <- glm(y_bin ~ duration, data = df_full, family = "binomial")
summary(model_glm_duration)

model_glm_pdays <- glm(y_bin ~ pdays, data = df_full, family = "binomial")
summary(model_glm_pdays)

# Finally, a multivariate regression comparing the correlation of all three aforementioned variables.
model_lm <- lm(y_bin ~ balance + duration + pdays, data = df_full)
summary(model_lm)


# Naive-Bayes Classification
# Herein we assume all independent variables are, indeed, independent.
# The bank data is a mix of categorical and quantitative variables, but the high prevalence of text-based attributes got me trying to use it.
# Our binary target variable is also categorical.
# From external sources, Naive-Bayes is considered a very efficient algorithm as well.
library(e1071)
set.seed(123)
# Train-test split for the classification.
sample_ybin <- sample(1:nrow(df_full), 0.7 * nrow(df_full))
train_data <- df_full[sample_ybin, ]
# For my testing data, I'm using the original df function, which contains 10% of the bank_full (df_full data),
# selected randomly.
df$y_bin <- ifelse(df$y == "yes", 1, ifelse(df$y == "no", 0, NA))
head(df)
test_data <- df[-sample_ybin, ]
# Training the classifier
model_naivebayes <- naiveBayes(y_bin ~ balance + duration + pdays + age + day, data = df_full)
ybin_predictions <- predict(model_naivebayes, test_data)
ybin_predictions
summary(ybin_predictions)
model_naivebayes
accuracy <- sum(ybin_predictions == test_data$y_bin) / nrow(test_data)
accuracy
# 0.8769537 was the value I got using both train and test values off df_full.
# 0.8887294 was the accuracy value I got using the "bank" (df) dataset for my test values.
# "An accuracy score of 0.8769537 implies the Naive Bayes classifier correctly predicted
# the class (species in this case) for approximately 87.70% of the instances in the test dataset."
plot(ybin_predictions)


# SVM
help("svm")
# svm is used to train a support vector machine.
# It can be used to carry out general regression and classification (of nu and epsilon-type), as well as density-estimation. A formula interface is provided.
library(e1071)
library(kernlab)
# Kernel function to build the rbfdot function in turn.
ksvm_data <- data.frame(x = df_full$y_bin, y = as.factor(df_full$balance))
ksvm_model <- ksvm(y ~ ., data = ksvm_data, type = "eps-svr", kernel = "rbfdot", kpar = list(sigma = 0.1))
predictions <- predict(ksvm_model, ksvm_data)
summary(predictions)
plot(df_full$y_bin, df_full$balance, col = "blue", pch = 16, main = "KSVR with RBF Kernel")

# Neither the SVM nor the KSVM fully work - I'm leaving it in predominantly just to show I tried.
set.seed(1)
x <- df_full$y_bin
y <- df_full$balance
#x[y==1,]=x[y==1,] + 1
dat = data.frame(x = df_full$y_bin, y = as.factor(df_full$balance))
help("svm")
svmfit <- svm(df_full$y_bin ~., data=dat, kernel="linear", cost=10, scale=FALSE)
plot(svmfit , dat)
summary(svmfit, dat)
