library(tidyverse)
library(randomForest)
df <- read.csv("communities.data", header=FALSE)
head(df)

#start_line <- 50
#end_line <- 2000
# Take the names of columns from the "communities.data" document.
start_line <- grep("Attribute Information: \\(122 predictive, 5 non-predictive, 1 goal\\)", readLines("communities.names"))
end_line <- grep("Summary Statistics:", readLines("communities.names"))
# Actually isolating the names of each category.
dfnames <- readLines("communities.names")[(start_line + 1):(end_line-2)]
dfnames
# We only need the community names, not their descriptions or the additional description text to the right.
# Clean them up, separate filler characters so the names look neater.
column_names <- sub(":.*", "", dfnames)
column_names <- sub("^-- ", "", column_names)
column_names
# Using the colnames function to apply column names to their respective place.
colnames(df) <- c(column_names)
df

# I find it messy that each communityname category is listed as "Aberdeentown", when
# the name of the community is "Aberdeen" and it's classified as a "town".
# I find four possible endings to each community title - "town", "city", "township"
# and "village". I create a separate column "communitytype" to describe the type of community.
df$communitytype <- sub(".*?(town|city|township|village)$", "\\1", df$communityname, ignore.case = TRUE)
df$communityname <- sub("(.*?)(town|city|township|village)$", "\\1", df$communityname, ignore.case = TRUE)
# Moving the communitytype column next to communityname.
communitytype_placement <- 5
# Removing the communitytype column at the end to avoid redundancy.
df <- cbind(df[, 1:(communitytype_placement - 1)], communitytype = df$communitytype, df[, communitytype_placement:ncol(df)])
#df

df <- df[, c(1:(communitytype_placement - 1), "communitytype", communitytype_placement:ncol(df))]

df <- df[, -ncol(df)] 
df

# There are 1994 rows in the dataframe.
nrow(df)
# Of these, LemasSwornFT, LemasSwFTPerPop, LemasSwFTFieldOps, LemasSwFTFieldPerPop,
# LemasTotalReq, LemasTotReqPerPop, PolicReqPerOffic, PolicPerPop, RacialMatchCommPol,
# PctPolicWhite, PctPolicBlack, PctPolicHisp, PctPolicAsian, PctPolicMinor, OfficAssgnDrugUnits,
# NumKindsDrugsSeiz, PolicAveOTWorked, PolicCars, PolicOperBudg, LemasPctPolicOnPatr, LemasGangUnitDeploy,
# and PolicBudgPerPop all have 1675 missing rows.
# That's 84% of all values, enough that we an remove these columns to reduce dimensionality.
library(dplyr)
start_column <- "LemasSwornFT"
end_column <- "PolicAveOTWorked"
start_pos <- match(start_column, names(df))
end_pos <- match(end_column, names(df))
df_red <- select(df, -seq(start_pos, end_pos))
df_red

# Now dropping the columns between and inclusive of "PolicCars" and "LamasGangUnitDeploy"
start_column2 <- "PolicCars"
end_column2 <- "LemasGangUnitDeploy"
start_pos2 <- match(start_column2, names(df_red))
end_pos2 <- match(end_column2, names(df_red))
# This check has been created (with the help of the internet) to check if the names are there to begin with.
if (!is.na(start_pos2) && !is.na(end_pos2)) {
  df <- select(df, -seq(start_pos2, end_pos2))
} else {
  warning("One or both of the specified columns not found.")
}
print(df_red)
df_red2 <- select(df_red, -seq(start_pos2, end_pos2))
df_red2

# Finally dropping the "PolicBudgPerPop" column since it's on its own. Not super efficient.
last_column_to_drop <- "PolicBudgPerPop"
df_red3 <- select(df_red2, -one_of(last_column_to_drop))
df_red3
df <- df_red3
df

# Our goal variable is violent crimes per population (ViolentCrimesPerPop).
# To better analyze the relationship between it and relevant variables, I'm using the
# PCA to reduce number of variables.

help("princomp")
# princomp performs a principal components analysis on the given numeric data matrix and returns 
# the results as an object of class princomp.

# Calculating the correlation matrix, checking for any nulls.

any(is.na(df))

# Determine the type of each column, to ensure that all variables used in measurement are numeric.
column_types <- sapply(df, class)
print(column_types)
# Specific backup dataframe featuring only "numeric" variables.
# Will be used for future operations to avoid confusion.
df_numeric <- df[sapply(df, is.numeric)]
#help("princomp")
# Principal component analysis.
principal_components <- princomp(df_numeric, cor = TRUE, score = TRUE)
principal_components
summary(principal_components) 
# Higher proportions indicate that the corresponding component is more important in capturing the variability in the data.
# The standard deviations of Components 1-14 are above 1, and have the highest importance.

plot(principal_components)
#princomp_sec = principal_components[, 1:14]
#princomp_sec
help("biplot")
biplot(principal_components)
# Making a biplot with 102 components is too messy to tell us anything.

set.seed(12345)

#print(df_numeric)
# ViolentCrimesPerPop: total number of violent crimes per 100K popuation (numeric - decimal) GOAL attribute (to be predicted)
goal_variable <- "ViolentCrimesPerPop"
columns_for_correlation <- c(goal_variable, names(df_numeric)[names(df_numeric) != goal_variable])
df_compare <- df[columns_for_correlation]
correlation_matrix <- cor(df_compare, use = "complete.obs")
# Too messy to tell us much, sorting the correlations with ViolentCrimesPerPop specifically.
#correlation_matrix

# So since we have so many variables to work with, let's figure out which ones correlate the most with ViolentCrimesPerPop.
# Extract correlations of target variables.
correlation_with_violent_crimes <- cor(df_numeric)[goal_variable, ]
# Sorting the extracted correlations.
sorted_correlations <- sort(correlation_with_violent_crimes, decreasing = TRUE)
# Printing the correlation values between ViolentCrimePerPop (our target variable) and the other numeric variables.
print(data.frame(Variable = names(sorted_correlations), Correlation = sorted_correlations))
# Most correlated variables are:
# 1. PctIlleg (percentage of kids born to never married (numeric - decimal), corr. 0.738
# 2. racepctblack (percentage of population that is african american (numeric - decimal)), corr. 0.631
# 3. pctWPubAsst (percentage of households with public assistance income in 1989), corr. 0.575
# 4. FemalePctDiv (percentage of females who are divorced (numeric - decimal)), corr. 0.556
# 5. TotalPctDiv (percentage of population who are divorced (numeric - decimal)), corr. 0.553
# 6. MalePctDivorce (percentage of males who are divorced (numeric - decimal)), corr. 0.525
# 7. PctPopUnderPov (percentage of people under the poverty level (numeric - decimal)), corr. 0.522
# 8. PctUnemployed (percentage of people 16 and over, in the labor force, and unemployed (numeric - decimal)), corr. 0.504
# 9. PctHousNoPhone (percent of occupied housing units without phone (in 1990, this was rare!) (numeric - decimal)), corr. 0.488
# 10. PctNotHSGrad (percentage of people 25 and over that are not high school graduates (numeric - decimal)), corr. 0.483

# Just out of personal bias, I would like to avoid using racepctblack in this dataset going forward.
# While it is the second-most correlated variable with violent crime, I don't think there's valuable solutions
# to be gained beyond racial profiling.

print(df$PctPopUnderPov)

target_variable <- "ViolentCrimesPerPop"
corr_variable <- "PctIlleg"

# While I'm aware of how to do ggplots, a lot of this function below is taken from StackOverflow.
# I wan into an issue making an actual ggplot and find that this works best.
ggplot(df, aes(x = df[[corr_variable]], y = df[[target_variable]])) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(title = paste("Correlation Plot between", target_variable, "and", corr_variable),
       x = corr_variable,
       y = target_variable) +
  geom_text(aes(label = sprintf("Correlation: %.2f", cor(df[[corr_variable]], df[[target_variable]]))),
            x = max(df[[corr_variable]]), y = max(df[[target_variable]]),
            hjust = 1, vjust = 1, color = "red")

qqplot(df[[target_variable]], df[[corr_variable]])

target_variable <- "ViolentCrimesPerPop"
corr_variable <- "racepctblack"

ggplot(df, aes(x = df[[corr_variable]], y = df[[target_variable]])) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(title = paste("Correlation Plot between", target_variable, "and", corr_variable),
       x = corr_variable,
       y = target_variable) +
  geom_text(aes(label = sprintf("Correlation: %.2f", cor(df[[corr_variable]], df[[target_variable]]))),
            x = max(df[[corr_variable]]), y = max(df[[target_variable]]),
            hjust = 1, vjust = 1, color = "red")

qqplot(df[[target_variable]], df[[corr_variable]])

target_variable <- "ViolentCrimesPerPop"
corr_variable <- "pctWPubAsst"

ggplot(df, aes(x = df[[corr_variable]], y = df[[target_variable]])) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(title = paste("Correlation Plot between", target_variable, "and", corr_variable),
       x = corr_variable,
       y = target_variable) +
  geom_text(aes(label = sprintf("Correlation: %.2f", cor(df[[corr_variable]], df[[target_variable]]))),
            x = max(df[[corr_variable]]), y = max(df[[target_variable]]),
            hjust = 1, vjust = 1, color = "red")

qqplot(df[[target_variable]], df[[corr_variable]])


# RandomForest - doesn't fully work, mostly here for any potential extra credit.

set.seed(100)
train <- sample(nrow(df), 0.7 * nrow(df), replace = FALSE)
TrainSet <- df[train,]
ValidSet <- df[-train,]
summary(TrainSet)
summary(ValidSet)
model1 <- randomForest(PctIlleg ~ ., data = TrainSet, importance = TRUE)
model1
# A high 92.87% percentage of variance explained indicates that the model is capturing a substantial amount of the variability in the response variable.
# Low mean error entails the model follows predicted values closely.
importance(model1) # importance of each predictor
# More or less a test run to see if everything works.
varImpPlot(model1)
plot(model1)
getTree(model1, 1, labelVar=TRUE)

model2 <- randomForest(PctIlleg ~ ., data = ValidSet, ntree = 500, mtry = 6, importance = TRUE)
model2
# Again, high variance indicates the model is capturing high variability, though less than in the Train set.

# Now to try with the control variable.
model_ctrl <- randomForest(ViolentCrimesPerPop ~ ., data = TrainSet, importance = TRUE)
model_ctrl
# A much lower % of variance is explained with the control variable than with PctIlleg.
# Low mean of squared residuals, once again the model's predictions are close to actual values.

importance(model_ctrl) # importance of each predictor
varImpPlot(model_ctrl)
plot(model_ctrl)
getTree(model_ctrl, 1, labelVar=TRUE)

predTrain <- predict(model2, TrainSet, type="class")
table(predTrain, TrainSet$ViolentCrimesPerPop)

predValid <- predict(model2, ValidSet, type="class")
table(predValid, ValidSet$ViolentCrimesPerPop)

# IncNodePurity is the total decrease in node impurities
# %IncMSE (% increase Mean Squared Error )is the increase in mse of predictions(estimated 
# with out-of-bag-CV) as a result of variable j being permuted(values randomly shuffled).

library(randomForest)
library(caret)
library(ggplot2)
library(rpart)
library(e1071)
# An attempt to perform a RandomForest classification.
i = 5

# a = c()
# i = 5
# for (i in 10:50) {
#   model <- randomForest(PctIlleg ~ ., data = TrainSet, ntree=500, mtry=i, importance=TRUE)
#   predValid <- predict(model3, ValidSet, type="class")
#   a[i-2] = mean(predValid == ValidSet$PctIlleg)
# }



# KNN

summary(df$ViolentCrimesPerPop)
# Not necessary here since it's all numeric, but just to remove any potential straggler variables.
df$ViolentCrimesPerPop <- as.numeric(df$ViolentCrimesPerPop)
boxplot <- boxplot(df$ViolentCrimesPerPop)
# Just in the interest of understanding its distribution.
# Performing further interquartile preprocessing to prep for the KNN model.
iqr_ViolentCrimes <- IQR(df$ViolentCrimesPerPop)
 print(iqr_ViolentCrimes)
median = median(df$ViolentCrimesPerPop)
print(median)

low_cutoff <- quantile(df$ViolentCrimesPerPop, 0.3333)
low_cutoff
medium_cutoff <- quantile(df$ViolentCrimesPerPop, 0.6667)
medium_cutoff
high_cutoff <- quantile(df$ViolentCrimesPerPop, 0.999)
high_cutoff
print(max(df$ViolentCrimesPerPop))

df$violentcrimes_cat <- cut(df$ViolentCrimesPerPop, br=c(-1, 0.09, 0.25, 1), labels=c('low', 'medium', 'high'))
df$violentcrimes_cat <- as.factor(df$violentcrimes_cat)
summary(df$violentcrimes_cat)
# low medium   high 
# 679    662    653
# 1994 categories total, checks out.

normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

#names(df)
# Top 5 variables - excluding variable about black population.
# Percentage of homeowners black is the second-highest correlated variable.
# Call me biased and unscientific, I don't think there are any productive findings
# to be made from correlating a race of people with the crime rate of a neighborhood.
corrdf <- df[, c("ViolentCrimesPerPop", "PctIlleg", "pctWPubAsst", "FemalePctDiv", "TotalPctDiv", "MalePctDivorce")]
head(corrdf)
corrdf$PctIlleg = as.numeric(gsub(',','',corrdf$pctWPubAsst))
corrdf$pctWPubAsst = as.numeric(gsub(',','',corrdf$pctWPubAsst))
corrdf$FemalePctDiv = as.numeric(gsub(',','',corrdf$FemalePctDiv))
corrdf$TotalPctDiv = as.numeric(gsub(',','',corrdf$TotalPctDiv))
corrdf$MalePctDivorce = as.numeric(gsub(',','',corrdf$MalePctDivorce))

ind <- sample(2, nrow(corrdf), replace=TRUE, prob=c(0.7, 0.3))
KNNtrain <- corrdf[ind==1,]
KNNtest <- corrdf[ind==2,]
# Our k-value is the square root of the total (1994) observations, roughly k=45

library(class)
KNNpred <- knn(train = KNNtrain, test = KNNtest, cl = KNNtrain$ViolentCrimesPerPop, k=45)
head(KNNpred)
summary(KNNpred)
table(KNNpred)

t.test(KNNtrain$ViolentCrimesPerPop)
t.test(KNNtest$ViolentCrimesPerPop)

t.test(KNNtrain$PctIlleg)
t.test(KNNtest$PctIlleg)

head(KNNpred)
summary(KNNpred)
table(KNNpred)
# 




# K-Means Algorithm

# K-Means randomly chooses k examples as initial centroids, and creates k-clusters
# by assigning each example as closest to centroid.
library(ISLR)
# head(df)

#features_ft <- df[, c("ViolentCrimesPerPop", "PctIlleg", "pctWPubAsst", "FemalePctDiv", "TotalPctDiv", "MalePctDivorce")]
# Correlation between target variable ViolentCrimesPerPop and most-correlated variable PctIlleg.
features_ft <- df[, c("ViolentCrimesPerPop", "PctIlleg")]
ft_standardized <- scale(features_ft)
k <- 5
kmeans_clustering_result <- kmeans(ft_standardized, centers = k, nstart = 10)
cluster_assignments <- kmeans_clustering_result$cluster

plot(features_ft, col = cluster_assignments, pch = 15, main = "K-Means Clustering Attempt")

library(cluster)

# Draws a 2-dimensional “clusplot” (clustering plot) on the current graphics device.
# The generic function has a default and a partition method.
help("clusplot")
# Perform k-means clustering on a data matrix.
help("kmeans")

# These two components explain 40.37% of the point variability.
clusplot(df, kmeans_clustering_result$cluster, color = TRUE, shade = TRUE, labels = 0, lines = 0)


df_clusters <- cbind(df, Cluster = cluster_assignments)
head(df_clusters)
help("cbind")

features_ft <- df[, c("ViolentCrimesPerPop", "PctKids2Par")]
ft_standardized <- scale(features_ft)
k <- 5
kmeans_clustering_result <- kmeans(ft_standardized, centers = k, nstart = 10)
cluster_assignments <- kmeans_clustering_result$cluster

plot(features_ft, col = cluster_assignments, pch = 15, main = "K-Means Clustering Attempt")


features_ft <- df[, c("ViolentCrimesPerPop", "pctWPubAsst")]
ft_standardized <- scale(features_ft)
k <- 5
kmeans_clustering_result <- kmeans(ft_standardized, centers = k, nstart = 10)
cluster_assignments <- kmeans_clustering_result$cluster

plot(features_ft, col = cluster_assignments, pch = 15, main = "K-Means Clustering Attempt")
